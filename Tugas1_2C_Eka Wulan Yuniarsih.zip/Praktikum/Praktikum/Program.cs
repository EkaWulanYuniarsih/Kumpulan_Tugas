﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktikum
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Aplikasi Konversi");
            Console.WriteLine("-------------------");

            // Konversi Waktu
            KonversiWaktu();

            // Konversi Suhu
            KonversiSuhu();

            Console .ReadKey();
        }

        static void KonversiWaktu()
        {
            Console.WriteLine("Aplikasi Konversi Waktu");
            int detik;

            while (true)
            {
                try
                {
                    Console.Write("Masukkan waktu dalam detik (tidak boleh negatif): ");
                    detik = Convert.ToInt32(Console.ReadLine());

                    if (detik < 0)
                    {
                        Console.WriteLine("Input tidak boleh negatif. Silakan masukkan angka non-negatif.");
                        continue;
                    }

                    break;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Input tidak valid. Masukkan angka bulat non-negatif.");
                }
            }

            int jam = detik / 3600;
            detik %= 3600;
            int menit = detik / 60;
            detik %= 60;
            Console.WriteLine($"Waktu: {jam} jam, {menit} menit, {detik} detik");
        }

        static void KonversiSuhu()
        {
            Console.WriteLine("Aplikasi Konversi Suhu");
            Console.WriteLine("________________________");
            float celsius;

            while (true)
            {
                try
                {
                    Console.Write("Masukkan suhu dalam Celsius: ");
                    celsius = float.Parse(Console.ReadLine());
                    break;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Input tidak valid. Masukkan angka desimal yang benar.");
                }
            }

            float fahrenheit = (celsius * 9 / 5) + 32;
            float kelvin = celsius + 273.15f;

            Console.WriteLine($"Fahrenheit: {fahrenheit} °F");
            Console.WriteLine($"Kelvin: {kelvin} K");

            Console.ReadKey();
        }

    }
}